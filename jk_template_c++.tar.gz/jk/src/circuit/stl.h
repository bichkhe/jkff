#ifndef _JK_ARRAY_H_
#define _JK_ARRAY_H_


/*
 * @author : bichkhe
 * @date : 26-07
 */

#include <array>
#include <iostream>
#include <map>
#include <vector>

using namespace std;


class JKArray 
{

 public:
  JKArray(){cout<< "Constructor---!"<<endl;}
  virtual ~JKArray(){ cout << "~Destructor !" <<endl;}
 
  
 private:
  
  array<string,100> mPeople;
  vector<string> mBooks;
  map<string, string> mOthers;
  
 public:
  
  void AddBook(const string& name);
};


#endif // end of JK_ARRAY_H_
